﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eshterak
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            Properties.Settings.Default.NameMaghaze = textBox1.Text.ToString();
            Properties.Settings.Default.isFirstTime = false;
            Properties.Settings.Default.Save();
            Properties.Settings.Default.Reload();
            new Forms.PrimaryForm().Show();
            this.Hide();
        }

        private void Home_Activated(object sender, EventArgs e)
        {
            if (Properties.Settings.Default.isFirstTime == false)
            {
                Home.ActiveForm.Hide();
                new Forms.PrimaryForm().Show();
                
            }
        }
    }
}
