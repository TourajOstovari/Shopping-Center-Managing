﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Eshterak.Methods.Set;
namespace Eshterak.Forms
{
    public partial class SabteMahsol : Form
    {
        public SabteMahsol()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new Forms.Mahsolat.HazfMahsol().ShowDialog();
        }

        private void textBox3_Leave(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(txt_Price.Text))
                txt_Price.Text = Convert.ToInt64(txt_Price.Text.Replace(",", "")).ToString("n0");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Set Sets = new Set();
            //if (Sets.Sets("Insert Into tbl_Mahsolat (Name,groop,Price) values('" + txt_Name.Text + "','" + txt_Group.Text + "','" + txt_Price.Text + "')") == 1)
            //{
            //    MessageBox.Show("اطلاعات با موفقیت ثبت شدند.","با موفقیت ثبت شد",MessageBoxButtons.OK,MessageBoxIcon.Information);
            //}
            //this.tbl_MahsolatTableAdapter.Fill(this.eshterakDataSet_Mahsolat.tbl_Mahsolat);

        }

        private void SabteMahsol_Load(object sender, EventArgs e)
        {
            this.tbl_MahsolatTableAdapter.Fill(this.eshterakDataSet_Mahsolat.tbl_Mahsolat);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_Price.ResetText(); txt_Name.ResetText(); txt_Group.ResetText();
        }

        private void SabteMahsol_Activated(object sender, EventArgs e)
        {
            this.tbl_MahsolatTableAdapter.Fill(this.eshterakDataSet_Mahsolat.tbl_Mahsolat);
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}
