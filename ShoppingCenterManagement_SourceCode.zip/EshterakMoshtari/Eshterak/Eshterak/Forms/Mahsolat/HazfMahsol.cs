﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Eshterak.Methods.Set;
namespace Eshterak.Forms.Mahsolat
{
    public partial class HazfMahsol : Form
    {
        public HazfMahsol()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void HazfMahsol_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'eshterakDataSet_Mahsolat.tbl_Mahsolat' table. You can move, or remove it, as needed.
            this.tbl_MahsolatTableAdapter.Fill(this.eshterakDataSet_Mahsolat.tbl_Mahsolat);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Set sets = new Set();
            try
            {
                sets.Sets("delete from tbl_Mahsolat where name='" + txt_Name.Text + "'");
            }
            catch (Exception ex)
            {
                MessageBox.Show(string.Concat("Error: ",ex.Message),"Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            finally
            {
                this.tbl_MahsolatTableAdapter.Fill(this.eshterakDataSet_Mahsolat.tbl_Mahsolat);
            }
        }

        private void HazfMahsol_Activated(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }
    }
}
