﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
namespace Eshterak.Forms.Moshtarekin
{
    public partial class MoshtarekinJadid : Form
    {
        public MoshtarekinJadid()
        {
            InitializeComponent();
        }
        String ConnectionString = "Data Source=LocalHost;Initial Catalog=Eshterak;Integrated Security=True";
        private void MoshtarekinJadid_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'eshterakDataSet_Moshtarek.tbl_Moshtarek' table. You can move, or remove it, as needed.
            this.tbl_MoshtarekTableAdapter.Fill(this.eshterakDataSet_Moshtarek.tbl_Moshtarek);
            
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //txtPhone.Text = txtPhone.Text.Trim();
            //MessageBox.Show(txtPhone.Text);
            //if (!string.IsNullOrEmpty(txtCode.Text) && !string.IsNullOrWhiteSpace(txtCode.Text) && !string.IsNullOrEmpty(txtName.Text) && !string.IsNullOrWhiteSpace(txtName.Text) && !string.IsNullOrEmpty(txtAddress.Text) && !string.IsNullOrWhiteSpace(txtAddress.Text) && !string.IsNullOrEmpty(txtPhone.Text) && !string.IsNullOrWhiteSpace(txtPhone.Text))
            //{
            //SetData("Insert Into tbl_Moshtarek(Code,Name,Address,Phone,Tel) values('" + txtCode.Text + "','" + txtName.Text + "','" + txtAddress.Text + "','" + txtPhone.Text + "','" + txtTel.Text + "')");
            //this.tbl_MoshtarekTableAdapter.Fill(this.eshterakDataSet_Moshtarek.tbl_Moshtarek);
            //dataGridView1.Refresh();
            //}
            //else
            //{
            //    MessageBox.Show("فیلد های مورد نیاز را تکمیل فرمایید لطفا.","ارور فیلد",MessageBoxButtons.OK,MessageBoxIcon.Error);
            //}
        }
        void SetData(string Commands)
        {
            bool sec = true;
            SqlConnection SqlCon = new SqlConnection(ConnectionString);
            SqlCommand sqlcmd = new SqlCommand(Commands, SqlCon);
            SqlCon.Open();
            try
            {
                sqlcmd.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                sec = false;
                MessageBox.Show("Error: "+ ex.Message,"Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            SqlCon.Close();
            SqlCon.Dispose();
            if (sec == true)
            {
                MessageBox.Show("داده ها با موفقیت ثب شدند.","موفقیت ثبت شد",MessageBoxButtons.OK,MessageBoxIcon.Information);
                txtAddress.ResetText(); txtCode.ResetText(); txtName.ResetText(); txtPhone.ResetText(); txtTel.ResetText();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Forms.Moshtarekin.HazfMoshtarek().Show();
            this.tbl_MoshtarekTableAdapter.Fill(this.eshterakDataSet_Moshtarek.tbl_Moshtarek);

        }

        private void MoshtarekinJadid_Activated(object sender, EventArgs e)
        {
            this.tbl_MoshtarekTableAdapter.Fill(this.eshterakDataSet_Moshtarek.tbl_Moshtarek);
            
        }
    }
}
