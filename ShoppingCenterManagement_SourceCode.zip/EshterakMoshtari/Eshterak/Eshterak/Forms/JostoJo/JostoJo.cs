﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Eshterak.Methods.Get;
namespace Eshterak.Forms.JostoJo
{
    public partial class JostoJo : Form
    {
        SByte CheckedItem = 1;
        public JostoJo()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if(radioButton1.Checked==true)
            {
                Group1.Enabled = true;
                Group3.Enabled = false;
                CheckedItem = 1;
            }
        }



        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton3.Checked == true)
            {
                Group1.Enabled = false;
                Group3.Enabled = true;
                CheckedItem = 3;
            }
        }

        private void JostoJo_Activated(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Get Gets = new Get();
            //switch (CheckedItem)
            //{
            //    case 1:
            //        dataGridView1.DataSource= Gets.GetData("select * from tbl_moshtarek where name='" + txt_name.Text + "'");
            //        dataGridView1.Refresh();
            //        dataGridView1.Columns[0].HeaderText = "کد اشتراک";
            //        dataGridView1.Columns[1].HeaderText = "نام و نام خانوادگی";
            //        dataGridView1.Columns[2].HeaderText = "آدرس";
            //        dataGridView1.Columns[2].Width = 180;
            //        dataGridView1.Columns[3].HeaderText = "تلفن همراه";
            //        dataGridView1.Columns[4].HeaderText = "منزل";
            //        break;
            //    case 3:
            //        dataGridView1.DataSource = Gets.GetData("select * from tbl_moshtarek where Code='" + txt_Code.Text + "'");
            //        dataGridView1.Refresh();
            //        dataGridView1.Columns[0].HeaderText = "کد اشتراک";
            //        dataGridView1.Columns[1].HeaderText = "نام و نام خانوادگی";
            //        dataGridView1.Columns[2].HeaderText = "آدرس";
            //        dataGridView1.Columns[2].Width = 180;
            //        dataGridView1.Columns[3].HeaderText = "تلفن همراه";
            //        dataGridView1.Columns[4].HeaderText = "منزل";

            //        break;
            //    default:
            //        Application.Exit();
            //        break;
            //}

        }
    }
}
