﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.Security.Cryptography;
namespace Eshterak.Forms.Activation
{
    public partial class frm_Activation : Form
    {
        public frm_Activation()
        {
            InitializeComponent();
        }

        private void frm_Activation_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(Eshterak.Properties.Settings.Default.Activated == false)
            {
                Application.Exit();
            }
        }

        private void frm_Activation_Load(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox1.ReadOnly = true;
            PersianCalendar PC = new PersianCalendar();
            SHA512CryptoServiceProvider SH512 = new SHA512CryptoServiceProvider();
            byte[] Input = UTF8Encoding.Unicode.GetBytes(System.Environment.MachineName + PC.GetYear(DateTime.Now));
            textBox1.Text = UTF8Encoding.Unicode.GetString(SH512.ComputeHash(Input));
            textBox2.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] EncryptedText = UTF8Encoding.Unicode.GetBytes(textBox1.Text);
            SHA512CryptoServiceProvider SH512 = new SHA512CryptoServiceProvider();
            if(textBox2.Text == UTF8Encoding.Unicode.GetString(SH512.ComputeHash(EncryptedText)))
            {
                Eshterak.Properties.Settings.Default.Activated = true;
                MessageBox.Show("لطفا نرم افزار را رستارت کنید تا تغییرات اعمال گردد. با تشکر از خرید شما." + "\nنرم افزار شما به مدت یک سال فعال گردید جهت تمدید با توسعه دهنده در تماس باشید.","فعال سازی موفق",MessageBoxButtons.OK,MessageBoxIcon.Information);
                PersianCalendar Persian = new PersianCalendar();
                Eshterak.Properties.Settings.Default.Expire = Convert.ToString(Persian.GetYear(DateTime.Now)+1) + "/" + Convert.ToString(Persian.GetMonth(DateTime.Now)) + "/" + Convert.ToString(Persian.GetDayOfMonth(DateTime.Now));
                Eshterak.Properties.Settings.Default.Save();
                Eshterak.Properties.Settings.Default.Reload();
                Application.Exit();
            }
            else
            {
                MessageBox.Show("فعال سازی با شکست روبرو شد با توسعه دهنده در تماس باشید لطفا\n تورج استواری 09145752930","Error!",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ActiveForm.Close();
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            textBox1.SelectAll();
        }
    }
}
