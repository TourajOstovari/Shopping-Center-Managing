﻿namespace Eshterak.Forms
{
    partial class PrimaryForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PrimaryForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ثبتمحصولToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ویرایشحذفToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتمحصولجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتمشتریجدیدToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.جستوجوToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ثبتسفارشToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.دربارهماToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.خروجToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ثبتمحصولToolStripMenuItem,
            this.ثبتمشتریجدیدToolStripMenuItem,
            this.جستوجوToolStripMenuItem,
            this.ثبتسفارشToolStripMenuItem,
            this.دربارهماToolStripMenuItem,
            this.خروجToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(8, 2, 0, 2);
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip1.ShowItemToolTips = true;
            this.menuStrip1.Size = new System.Drawing.Size(764, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ثبتمحصولToolStripMenuItem
            // 
            this.ثبتمحصولToolStripMenuItem.CheckOnClick = true;
            this.ثبتمحصولToolStripMenuItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.ثبتمحصولToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ویرایشحذفToolStripMenuItem,
            this.ثبتمحصولجدیدToolStripMenuItem});
            this.ثبتمحصولToolStripMenuItem.Name = "ثبتمحصولToolStripMenuItem";
            this.ثبتمحصولToolStripMenuItem.Size = new System.Drawing.Size(100, 20);
            this.ثبتمحصولToolStripMenuItem.Text = "مدیریت محصول";
            this.ثبتمحصولToolStripMenuItem.Click += new System.EventHandler(this.ثبتمحصولToolStripMenuItem_Click);
            this.ثبتمحصولToolStripMenuItem.MouseHover += new System.EventHandler(this.ثبتمحصولToolStripMenuItem_MouseHover);
            // 
            // ویرایشحذفToolStripMenuItem
            // 
            this.ویرایشحذفToolStripMenuItem.Name = "ویرایشحذفToolStripMenuItem";
            this.ویرایشحذفToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.ویرایشحذفToolStripMenuItem.Text = "حذف محصول";
            this.ویرایشحذفToolStripMenuItem.Click += new System.EventHandler(this.ویرایشحذفToolStripMenuItem_Click);
            // 
            // ثبتمحصولجدیدToolStripMenuItem
            // 
            this.ثبتمحصولجدیدToolStripMenuItem.Name = "ثبتمحصولجدیدToolStripMenuItem";
            this.ثبتمحصولجدیدToolStripMenuItem.Size = new System.Drawing.Size(162, 22);
            this.ثبتمحصولجدیدToolStripMenuItem.Text = "ثبت محصول جدید";
            this.ثبتمحصولجدیدToolStripMenuItem.Click += new System.EventHandler(this.ثبتمحصولجدیدToolStripMenuItem_Click);
            // 
            // ثبتمشتریجدیدToolStripMenuItem
            // 
            this.ثبتمشتریجدیدToolStripMenuItem.Name = "ثبتمشتریجدیدToolStripMenuItem";
            this.ثبتمشتریجدیدToolStripMenuItem.Size = new System.Drawing.Size(103, 20);
            this.ثبتمشتریجدیدToolStripMenuItem.Text = "ثبت مشترک جدید";
            this.ثبتمشتریجدیدToolStripMenuItem.Click += new System.EventHandler(this.ثبتمشتریجدیدToolStripMenuItem_Click);
            // 
            // جستوجوToolStripMenuItem
            // 
            this.جستوجوToolStripMenuItem.Name = "جستوجوToolStripMenuItem";
            this.جستوجوToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.جستوجوToolStripMenuItem.Text = "جستوجو";
            this.جستوجوToolStripMenuItem.Click += new System.EventHandler(this.جستوجوToolStripMenuItem_Click);
            // 
            // ثبتسفارشToolStripMenuItem
            // 
            this.ثبتسفارشToolStripMenuItem.Name = "ثبتسفارشToolStripMenuItem";
            this.ثبتسفارشToolStripMenuItem.Size = new System.Drawing.Size(78, 20);
            this.ثبتسفارشToolStripMenuItem.Text = "ثبت سفارش";
            this.ثبتسفارشToolStripMenuItem.Click += new System.EventHandler(this.ثبتسفارشToolStripMenuItem_Click);
            // 
            // دربارهماToolStripMenuItem
            // 
            this.دربارهماToolStripMenuItem.Name = "دربارهماToolStripMenuItem";
            this.دربارهماToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.دربارهماToolStripMenuItem.Text = "درباره ما";
            this.دربارهماToolStripMenuItem.Click += new System.EventHandler(this.دربارهماToolStripMenuItem_Click);
            // 
            // خروجToolStripMenuItem
            // 
            this.خروجToolStripMenuItem.Name = "خروجToolStripMenuItem";
            this.خروجToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.خروجToolStripMenuItem.Text = "خروج";
            this.خروجToolStripMenuItem.Click += new System.EventHandler(this.خروجToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.button1.Location = new System.Drawing.Point(507, 47);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(241, 39);
            this.button1.TabIndex = 1;
            this.button1.Text = "ثبت محصول جدید";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.button2.Location = new System.Drawing.Point(507, 106);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(241, 39);
            this.button2.TabIndex = 1;
            this.button2.Text = "ثبت مشخصات مشترک جدید";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.button3.Location = new System.Drawing.Point(507, 167);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(241, 39);
            this.button3.TabIndex = 1;
            this.button3.Text = "جستوجو ";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.button4.Location = new System.Drawing.Point(507, 274);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(112, 39);
            this.button4.TabIndex = 1;
            this.button4.Text = "خروج";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(41)))), ((int)(((byte)(128)))), ((int)(((byte)(185)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(236)))), ((int)(((byte)(240)))), ((int)(((byte)(241)))));
            this.button5.Location = new System.Drawing.Point(636, 274);
            this.button5.Margin = new System.Windows.Forms.Padding(4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(112, 39);
            this.button5.TabIndex = 1;
            this.button5.Text = "درباره ما";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 54);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(270, 202);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(150, 274);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "کاربر گرامی خوش آمدید.";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(104, 297);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(181, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "اعتبار نرم افزار تا تاریخ معتبر است:";
            // 
            // PrimaryForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(764, 329);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "PrimaryForm";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "خوش آمدید به نرم افزار مدیریت اشتراک";
            this.Activated += new System.EventHandler(this.PrimaryForm_Activated);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.PrimaryForm_FormClosing);
            this.Load += new System.EventHandler(this.PrimaryForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ثبتمشتریجدیدToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتمحصولToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem جستوجوToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ویرایشحذفToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.ToolStripMenuItem دربارهماToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem خروجToolStripMenuItem;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem ثبتسفارشToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ثبتمحصولجدیدToolStripMenuItem;
    }
}