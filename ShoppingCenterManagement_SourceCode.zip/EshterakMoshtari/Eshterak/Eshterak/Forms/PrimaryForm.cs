﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Eshterak.Forms
{
    public partial class PrimaryForm : Form
    {
        public PrimaryForm()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void خروجToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            new AboutMe().ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            new SabteMahsol().ShowDialog();
        }

        private void دربارهماToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AboutMe().ShowDialog();
        }

        private void ثبتمحصولToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            new Moshtarekin.MoshtarekinJadid().ShowDialog();
        }

        private void ثبتمشتریجدیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Moshtarekin.MoshtarekinJadid().ShowDialog();
        }

        private void PrimaryForm_Load(object sender, EventArgs e)
        {
            //MessageBox.Show(DateTime.Now.Year.ToString());
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new JostoJo.JostoJo().Show();
        }

        private void جستوجوToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new JostoJo.JostoJo().Show();
        }

        private void ثبتسفارشToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new SabtSefaresh.frmSabteSefaresh().Show();
        }

        private void PrimaryForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void ثبتمحصولToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {
        }

        private void ثبتمحصولجدیدToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new SabteMahsol().ShowDialog();
        }

        private void ویرایشحذفToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new Forms.Mahsolat.HazfMahsol().Show();
        }

        private void PrimaryForm_Activated(object sender, EventArgs e)
        {
            //if(Eshterak.Properties.Settings.Default.Activated == false)
            //{
            //    new Eshterak.Forms.Activation.frm_Activation().ShowDialog();
            //}
        }
    }
}
