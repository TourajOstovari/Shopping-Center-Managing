﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using Stimulsoft.Report;

using Eshterak.Methods.Set;

namespace Eshterak.Forms.SabtSefaresh
{
    public partial class frmSabteSefaresh : Form
    {
        public frmSabteSefaresh()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

            toolStripStatusLabel4.Text = string.Concat(DateTime.Now.Hour, ":",DateTime.Now.Minute);
            PersianCalendar pd = new PersianCalendar();
            toolStripStatusLabel2.Text = string.Concat(pd.GetYear(DateTime.Now),"/",pd.GetMonth(DateTime.Now),"/",pd.GetDayOfMonth(DateTime.Now));
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {
            toolStripStatusLabel4.Text = string.Concat(DateTime.Now.Hour, ":", DateTime.Now.Minute);
            PersianCalendar pd = new PersianCalendar();
            toolStripStatusLabel2.Text = string.Concat(pd.GetYear(DateTime.Now), "/", pd.GetMonth(DateTime.Now), "/", pd.GetDayOfMonth(DateTime.Now));


        }

        private void frmSabteSefaresh_Activated(object sender, EventArgs e)
        {
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        }

        private void frmSabteSefaresh_Load(object sender, EventArgs e)
        {
            comboBox1.Items.Clear();
            comboBox1.Items.Add("-----");
            
            Eshterak.Methods.Get.Get GetsPrice = new Methods.Get.Get();
            DataTable DT = new DataTable();
            DT = GetsPrice.GetData("Select groop from tbl_Mahsolat");
            foreach (DataRow columns in DT.Rows)
            {
                if(!comboBox1.Items.Contains(columns[0].ToString().Trim()))
                comboBox1.Items.Add(columns[0].ToString().Trim());
            }

        }

        private void comboBox1_TextUpdate(object sender, EventArgs e)
        {
        }

        private void comboBox1_TextChanged(object sender, EventArgs e)
        {
            comboBox2_1.Text = null;
            comboBox3.Items.Clear();
            comboBox3.Text = null;

            comboBox2_1.Items.Clear();
            Eshterak.Methods.Get.Get GetsPrice = new Methods.Get.Get();
            DataTable DT = new DataTable();
            DT = GetsPrice.GetData("Select Name from tbl_Mahsolat where groop='" + comboBox1.Text.Trim() + "'");
            foreach (DataRow columns in DT.Rows)
            {
                comboBox2_1.Items.Add(columns[0].ToString().Trim());
            }
       }

        private void comboBox2_1_TextChanged(object sender, EventArgs e)
        {
            comboBox3.Items.Clear();
            comboBox3.ResetText();
            Eshterak.Methods.Get.Get GetsPrice = new Methods.Get.Get();
            DataTable DT = new DataTable();
            DT = GetsPrice.GetData("Select Price from tbl_Mahsolat where name='" + comboBox2_1.Text.Trim() + "'");
            foreach (DataRow columns in DT.Rows)
            {
                comboBox3.Items.Add(columns[0].ToString().Trim());
            }
            if(comboBox3.Items.Count > 0)
            comboBox3.SelectedText = comboBox3.Items[0].ToString();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            comboBox1.ResetText(); comboBox2_1.ResetText(); comboBox3.ResetText();
            dataGridView1.Rows.Clear(); textBox1.ResetText(); maskedTextBox1.ResetText(); richTextBox1.ResetText();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            Set Sets = new Set();
            Sets.Sets("Delete FROM tbl_orders");
            foreach (DataGridViewRow DR in dataGridView1.Rows)
            {
                Sets.Sets("Insert Into tbl_Orders(Mahsol,Tedad,Price,TotalPrice) values('" + DR.Cells[1].Value.ToString() + "','" + DR.Cells[2].Value.ToString() + "','" + DR.Cells[3].Value.ToString() + "','" + DR.Cells[4].Value.ToString() + "')");
            }
            StiReport report = new StiReport();
            report.Load("Report.mrt");
            Eshterak.Methods.Get.Get gets = new Eshterak.Methods.Get.Get();
            
            report.RegData(gets.GetData("select * from tbl_Orders"));
            report.Dictionary.Variables["txtPersonName"].Value = textBox1.Text.Trim().ToString();
            report.Dictionary.Variables["txtPhone"].Value = maskedTextBox1.Text.Trim().ToString();
            report.Dictionary.Variables["txtAddress"].Value = richTextBox1.Text.ToString();
            report.Dictionary.Variables["txtRestuarant"].Value = Eshterak.Properties.Settings.Default.NameMaghaze.ToString();
            report.Show();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            /*
             In miad yek row be datagridview motabeg baa Text ha anjam mide ...
             */
            //dataGridView1.Rows.Insert(dataGridView1.NewRowIndex+1, Convert.ToString(comboBox1.Text),Convert.ToString(comboBox2_1.Text),Convert.ToString(numericUpDown1.Value.ToString()),Convert.ToString(comboBox3.Text), Convert.ToString(Math.BigMul(int.Parse(comboBox3.Text.Replace(",","").ToString()),int.Parse(numericUpDown1.Value.ToString()))));
        }
    }
}
