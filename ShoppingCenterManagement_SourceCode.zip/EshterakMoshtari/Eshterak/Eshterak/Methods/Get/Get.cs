﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
namespace Eshterak.Methods.Get
{
    public class Get {

        public StringBuilder SqlConnectionString =new StringBuilder( "Data Source=LocalHost;Initial Catalog=Eshterak;Integrated Security=True");
        public DataTable GetData(String SqlCommands)
        {
            DataTable DT = new DataTable();
            try { 
            SqlConnection sqlCon = new SqlConnection(SqlConnectionString.ToString());
            SqlCommand SqlCmd = new SqlCommand(SqlCommands, sqlCon);
            SqlDataAdapter SqlAdaptor = new SqlDataAdapter();
            sqlCon.Open();
            SqlAdaptor.SelectCommand = SqlCmd;
            SqlAdaptor.Fill(DT);
            sqlCon.Close();
            sqlCon.Dispose();
            SqlCmd.Dispose();
            SqlAdaptor.Dispose();
            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(string.Concat("Error: ",ex.Message),"Error!",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
            }
            
            return DT;
            

        }
    }
}
