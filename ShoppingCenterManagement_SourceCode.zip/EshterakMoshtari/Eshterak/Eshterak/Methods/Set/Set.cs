﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Eshterak.Methods.Set
{
    class Set
    {
        string ConnectionString = "Data Source=LocalHost;Initial Catalog = Eshterak; Integrated Security = True";
        public int Sets(string SQLCommand)
        {
            try { 
            SqlConnection SqlCon = new SqlConnection(ConnectionString);
            SqlCommand SqlCmd = new SqlCommand(SQLCommand, SqlCon);
                SqlCon.Open();
                SqlCmd.ExecuteNonQuery();
                SqlCon.Close();
                SqlCon.Dispose();

            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Error: "+ ex.Message,"Error!",System.Windows.Forms.MessageBoxButtons.OK,System.Windows.Forms.MessageBoxIcon.Error);
                return 0;
            }
            return 1;
        }
    }
}
